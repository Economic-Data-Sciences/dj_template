export { default } from './slider-parallax';
