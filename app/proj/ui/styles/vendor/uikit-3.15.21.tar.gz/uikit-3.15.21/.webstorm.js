// Webstorm Module resolution config
System.config({
    paths: {
        'uikit-util': './src/js/util/index.js',
    },
});
